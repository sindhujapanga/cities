package com.example;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor

public class CityPojo {

    private String name;
    private String state;
    private double latitude;
    private double longitude;

    @Override
    public String toString() {
        return super.toString();
    }
}
