package com.example;

import com.example.CityPojo;
import com.example.CityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@RestController
@RequestMapping("api")
public class CityController {

    @Autowired
    private CityService cityService;
    @GetMapping("city")
    public List<CityPojo> getCity(@RequestParam double lat, @RequestParam double lon){
        String url = "https://gist.githubusercontent.com/dastagirkhan/00a6f6e32425e0944241/raw/33ca4e2b19695b2b93f490848314268ed5519894/gistfile1.json";
        List<CityPojo> city = cityService.getCityFromUrl(url);
        return cityService.findCities(city, lat, lon);
    }

}



