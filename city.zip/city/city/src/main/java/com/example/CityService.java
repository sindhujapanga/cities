package com.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CityService {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private ObjectMapper objectMapper;
    public List<CityPojo> getCityFromUrl(String url) {
        ResponseEntity<CityPojo[]> res = restTemplate.getForEntity(url,CityPojo[].class);
        CityPojo[][] cities = new CityPojo[][]{res.getBody()};
        return (List<CityPojo>) Arrays.asList(cities);
    }
    public List<CityPojo> findCities(List<CityPojo> cities, double lat, double lon){
        return cities.stream()
                .filter(city->city.getLatitude()== lat && city.getLongitude() ==lon)
                .collect(Collectors.toList());
    }
}
