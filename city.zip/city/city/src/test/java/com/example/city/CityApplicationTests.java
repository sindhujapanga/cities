package com.example.city;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CityApplicationTests {

	@Test
	void contextLoads() {
	}

}
